﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpeechRecognizer
{
	public static class Constants
	{
		//Well, not so much constants here yet.

		internal static string GoogleRequestString =
			"https://www.google.com/speech-api/v1/recognize?xjerr=1&client=chromium&lang=ru-RU";
	}
}

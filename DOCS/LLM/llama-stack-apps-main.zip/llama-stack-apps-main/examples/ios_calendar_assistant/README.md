# iOSCalendarAssistant

iOSCalendarAssistant is a demo app that takes a meeting transcript, summarizes it, extracts action items, and calls tools to book any followup meetings.

You can connect it to a remote Llama Stack distribution or run inference on-device with [ExecuTorch](https://github.com/pytorch/executorch).

import SwiftUI
@main
struct iOSCalendarAssistantApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

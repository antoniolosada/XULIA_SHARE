namespace GoogleSpeechToTextLib
{
    public class GoogleVoice
    {
        public static string ACCESS_GOOGLE_SPEECH_KEY = "AIzaSyDC8nM1S0cLpXvRc8TXrDoey-tqQsoBGnM";
        public static string TEST_NEW_PATH_2014_PART =
            "https://www.google.com/speech-api/v2/recognize?output=json&lang=en-us&key=";

        public static string NOT_MY_KEY = "AIzaSyCnl6MRydhw_5fLXIdASxkLJzcJh5iX0M4";
        public static String GoogleSpeechRequest(String flacName, int sampleRate)
        {
            PATH = TEST_NEW_PATH_2014_PART + ACCESS_GOOGLE_SPEECH_KEY;
            HttpWebRequest request =(HttpWebRequest) HttpWebRequest.Create(PATH);
            request.Method = "POST";
            byte[] byteArray = File.ReadAllBytes(flacName);
            sampleRate = 44100;
            request.ContentType = "audio/x-flac; rate=" + sampleRate.ToString();        
            request.ContentLength = byteArray.Length;
            Stream sendStream = request.GetRequestStream();
            sendStream.Write(byteArray,0,byteArray.Length);
            sendStream.Close();
            string responseFromServer;
            HttpWebResponse response = (HttpWebResponse) request.GetResponse();
            var reader = new StreamReader(response.GetResponseStream());
            responseFromServer = reader.ReadToEnd();
            reader.Close();
            response.Close();
            return responseFromServer;
        }
    }
}